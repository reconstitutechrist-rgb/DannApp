"use client";

import AIBuilder from '@/components/AIBuilder';

export default function HomePage() {
  return (
    <AIBuilder />
  );
}